package com.example.clase22.servicio;

public class DomicilioService {

}
