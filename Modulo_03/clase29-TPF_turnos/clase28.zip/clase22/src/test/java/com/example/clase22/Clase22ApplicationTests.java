package com.example.clase22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
